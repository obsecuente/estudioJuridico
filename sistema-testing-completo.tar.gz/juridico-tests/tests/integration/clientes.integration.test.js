import request from 'supertest';
import app from '../../server.js';
import { limpiarTablas, crearClientePrueba, crearMultiplesClientes } from '../helpers/dbHelpers.js';
import { generarEmailUnico, generarTelefonoUnico } from '../helpers/testData.js';

describe('API Integration - Clientes Endpoints', () => {
  
  beforeEach(async () => {
    await limpiarTablas();
  });

  // ============================================
  // POST /api/clientes - CREAR CLIENTE
  // ============================================

  describe('POST /api/clientes', () => {
    
    test('debe crear un cliente y retornar 201', async () => {
      const nuevoCliente = {
        nombre: 'Juan',
        apellido: 'Pérez',
        email: generarEmailUnico(),
        telefono: generarTelefonoUnico(),
        consentimiento_datos: true,
      };

      const response = await request(app)
        .post('/api/clientes')
        .send(nuevoCliente)
        .expect('Content-Type', /json/)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('creado exitosamente');
      expect(response.body.data).toHaveProperty('id_cliente');
      expect(response.body.data.nombre).toBe('Juan');
      expect(response.body.data.email).toBe(nuevoCliente.email.toLowerCase());
    });

    test('debe retornar 400 sin nombre', async () => {
      const response = await request(app)
        .post('/api/clientes')
        .send({
          apellido: 'Pérez',
          email: generarEmailUnico(),
          telefono: generarTelefonoUnico(),
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('obligatorios');
    });

    test('debe retornar 400 sin apellido', async () => {
      const response = await request(app)
        .post('/api/clientes')
        .send({
          nombre: 'Juan',
          email: generarEmailUnico(),
          telefono: generarTelefonoUnico(),
        })
        .expect(400);

      expect(response.body.success).toBe(false);
    });

    test('debe retornar 400 sin email', async () => {
      const response = await request(app)
        .post('/api/clientes')
        .send({
          nombre: 'Juan',
          apellido: 'Pérez',
          telefono: generarTelefonoUnico(),
        })
        .expect(400);

      expect(response.body.success).toBe(false);
    });

    test('debe retornar 400 con email inválido', async () => {
      const response = await request(app)
        .post('/api/clientes')
        .send({
          nombre: 'Juan',
          apellido: 'Pérez',
          email: 'email-invalido',
          telefono: generarTelefonoUnico(),
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('formato del mail');
    });

    test('debe retornar 400 con teléfono inválido', async () => {
      const response = await request(app)
        .post('/api/clientes')
        .send({
          nombre: 'Juan',
          apellido: 'Pérez',
          email: generarEmailUnico(),
          telefono: '123456',
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('formato del numero de telefono');
    });

    test('debe retornar 409 con email duplicado', async () => {
      const email = generarEmailUnico();
      await crearClientePrueba({ email });

      const response = await request(app)
        .post('/api/clientes')
        .send({
          nombre: 'Pedro',
          apellido: 'López',
          email: email,
          telefono: generarTelefonoUnico(),
        })
        .expect(409);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('Ya existe');
    });

    test('debe retornar 409 con teléfono duplicado', async () => {
      const telefono = generarTelefonoUnico();
      await crearClientePrueba({ telefono });

      const response = await request(app)
        .post('/api/clientes')
        .send({
          nombre: 'Pedro',
          apellido: 'López',
          email: generarEmailUnico(),
          telefono: telefono,
        })
        .expect(409);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('Ya existe');
    });

    test('debe normalizar email a minúsculas', async () => {
      const response = await request(app)
        .post('/api/clientes')
        .send({
          nombre: 'Juan',
          apellido: 'Pérez',
          email: 'EMAIL@TEST.COM',
          telefono: generarTelefonoUnico(),
        })
        .expect(201);

      expect(response.body.data.email).toBe('email@test.com');
    });

    test('debe rechazar body vacío', async () => {
      const response = await request(app)
        .post('/api/clientes')
        .send({})
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });

  // ============================================
  // GET /api/clientes - OBTENER TODOS
  // ============================================

  describe('GET /api/clientes', () => {
    
    test('debe obtener lista vacía si no hay clientes', async () => {
      const response = await request(app)
        .get('/api/clientes')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toEqual([]);
      expect(response.body.pagination.total).toBe(0);
    });

    test('debe obtener lista de clientes', async () => {
      await crearClientePrueba({ nombre: 'Juan' });
      await crearClientePrueba({ nombre: 'Pedro' });

      const response = await request(app)
        .get('/api/clientes')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveLength(2);
      expect(response.body.pagination).toBeDefined();
    });

    test('debe aplicar paginación', async () => {
      await crearMultiplesClientes(10);

      const response = await request(app)
        .get('/api/clientes?page=1&limit=3')
        .expect(200);

      expect(response.body.data).toHaveLength(3);
      expect(response.body.pagination.total).toBe(10);
      expect(response.body.pagination.page).toBe(1);
      expect(response.body.pagination.limit).toBe(3);
      expect(response.body.pagination.totalPages).toBe(4);
    });

    test('debe obtener segunda página', async () => {
      await crearMultiplesClientes(10);

      const response = await request(app)
        .get('/api/clientes?page=2&limit=3')
        .expect(200);

      expect(response.body.data).toHaveLength(3);
      expect(response.body.pagination.page).toBe(2);
    });

    test('debe aplicar búsqueda por nombre', async () => {
      await crearClientePrueba({ nombre: 'Juan' });
      await crearClientePrueba({ nombre: 'Pedro' });

      const response = await request(app)
        .get('/api/clientes?search=Juan')
        .expect(200);

      expect(response.body.data).toHaveLength(1);
      expect(response.body.data[0].nombre).toBe('Juan');
    });

    test('debe retornar campos específicos', async () => {
      await crearClientePrueba();

      const response = await request(app)
        .get('/api/clientes')
        .expect(200);

      const cliente = response.body.data[0];
      expect(cliente).toHaveProperty('id_cliente');
      expect(cliente).toHaveProperty('nombre');
      expect(cliente).toHaveProperty('apellido');
      expect(cliente).toHaveProperty('email');
      expect(cliente).toHaveProperty('telefono');
      expect(cliente).toHaveProperty('fecha_registro');
      expect(cliente).toHaveProperty('consentimiento_datos');
    });

    test('debe usar límite por defecto de 20', async () => {
      await crearMultiplesClientes(25);

      const response = await request(app)
        .get('/api/clientes')
        .expect(200);

      expect(response.body.data).toHaveLength(20);
    });
  });

  // ============================================
  // GET /api/clientes/:id - OBTENER POR ID
  // ============================================

  describe('GET /api/clientes/:id', () => {
    
    test('debe obtener cliente por ID', async () => {
      const cliente = await crearClientePrueba();

      const response = await request(app)
        .get(`/api/clientes/${cliente.id_cliente}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.id_cliente).toBe(cliente.id_cliente);
      expect(response.body.data.nombre).toBe(cliente.nombre);
    });

    test('debe incluir consultas del cliente', async () => {
      const cliente = await crearClientePrueba();

      const response = await request(app)
        .get(`/api/clientes/${cliente.id_cliente}`)
        .expect(200);

      expect(response.body.data).toHaveProperty('consultas');
      expect(Array.isArray(response.body.data.consultas)).toBe(true);
    });

    test('debe incluir casos del cliente', async () => {
      const cliente = await crearClientePrueba();

      const response = await request(app)
        .get(`/api/clientes/${cliente.id_cliente}`)
        .expect(200);

      expect(response.body.data).toHaveProperty('casos');
      expect(Array.isArray(response.body.data.casos)).toBe(true);
    });

    test('debe retornar 404 si no existe', async () => {
      const response = await request(app)
        .get('/api/clientes/99999')
        .expect(404);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('no encontrado');
    });

    test('debe retornar 404 con ID inválido', async () => {
      const response = await request(app)
        .get('/api/clientes/abc')
        .expect(404);

      expect(response.body.success).toBe(false);
    });
  });

  // ============================================
  // GET /api/clientes/search - BUSCAR
  // ============================================

  describe('GET /api/clientes/search', () => {
    
    test('debe buscar clientes por nombre', async () => {
      await crearClientePrueba({ nombre: 'Juan', apellido: 'García' });
      await crearClientePrueba({ nombre: 'Pedro', apellido: 'López' });

      const response = await request(app)
        .get('/api/clientes/search?q=Juan')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveLength(1);
      expect(response.body.data[0].nombre).toBe('Juan');
    });

    test('debe buscar clientes por apellido', async () => {
      await crearClientePrueba({ apellido: 'García' });
      await crearClientePrueba({ apellido: 'López' });

      const response = await request(app)
        .get('/api/clientes/search?q=García')
        .expect(200);

      expect(response.body.data).toHaveLength(1);
      expect(response.body.data[0].apellido).toBe('García');
    });

    test('debe retornar 400 con término muy corto', async () => {
      const response = await request(app)
        .get('/api/clientes/search?q=J')
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('al menos 2 caracteres');
    });

    test('debe retornar 400 sin parámetro q', async () => {
      const response = await request(app)
        .get('/api/clientes/search')
        .expect(400);

      expect(response.body.success).toBe(false);
    });

    test('debe limitar resultados a 10', async () => {
      for (let i = 0; i < 15; i++) {
        await crearClientePrueba({ apellido: 'García' });
      }

      const response = await request(app)
        .get('/api/clientes/search?q=García')
        .expect(200);

      expect(response.body.data).toHaveLength(10);
    });

    test('debe incluir total de resultados', async () => {
      await crearClientePrueba({ nombre: 'Juan' });

      const response = await request(app)
        .get('/api/clientes/search?q=Juan')
        .expect(200);

      expect(response.body).toHaveProperty('total');
      expect(response.body.total).toBe(1);
    });
  });

  // ============================================
  // PUT /api/clientes/:id - ACTUALIZAR
  // ============================================

  describe('PUT /api/clientes/:id', () => {
    
    test('debe actualizar nombre del cliente', async () => {
      const cliente = await crearClientePrueba({ nombre: 'Juan' });

      const response = await request(app)
        .put(`/api/clientes/${cliente.id_cliente}`)
        .send({ nombre: 'Pedro' })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.nombre).toBe('Pedro');
      expect(response.body.message).toContain('actualizado');
    });

    test('debe actualizar múltiples campos', async () => {
      const cliente = await crearClientePrueba();

      const response = await request(app)
        .put(`/api/clientes/${cliente.id_cliente}`)
        .send({
          nombre: 'Nuevo',
          apellido: 'Nombre',
        })
        .expect(200);

      expect(response.body.data.nombre).toBe('Nuevo');
      expect(response.body.data.apellido).toBe('Nombre');
    });

    test('debe retornar 404 si no existe', async () => {
      const response = await request(app)
        .put('/api/clientes/99999')
        .send({ nombre: 'Pedro' })
        .expect(404);

      expect(response.body.success).toBe(false);
    });

    test('debe retornar 409 con email duplicado', async () => {
      const cliente1 = await crearClientePrueba();
      const cliente2 = await crearClientePrueba();

      const response = await request(app)
        .put(`/api/clientes/${cliente2.id_cliente}`)
        .send({ email: cliente1.email })
        .expect(409);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('Ya existe');
    });

    test('debe permitir actualizar sin cambiar email', async () => {
      const cliente = await crearClientePrueba();

      const response = await request(app)
        .put(`/api/clientes/${cliente.id_cliente}`)
        .send({
          nombre: 'Nuevo Nombre',
          email: cliente.email,
        })
        .expect(200);

      expect(response.body.success).toBe(true);
    });

    test('debe aceptar body vacío', async () => {
      const cliente = await crearClientePrueba();

      const response = await request(app)
        .put(`/api/clientes/${cliente.id_cliente}`)
        .send({})
        .expect(200);

      expect(response.body.success).toBe(true);
    });
  });

  // ============================================
  // DELETE /api/clientes/:id - ELIMINAR
  // ============================================

  describe('DELETE /api/clientes/:id', () => {
    
    test('debe eliminar cliente', async () => {
      const cliente = await crearClientePrueba();

      const response = await request(app)
        .delete(`/api/clientes/${cliente.id_cliente}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('eliminado');
    });

    test('debe retornar 404 si no existe', async () => {
      const response = await request(app)
        .delete('/api/clientes/99999')
        .expect(404);

      expect(response.body.success).toBe(false);
    });

    test('cliente eliminado no debe existir en la base de datos', async () => {
      const cliente = await crearClientePrueba();

      await request(app)
        .delete(`/api/clientes/${cliente.id_cliente}`)
        .expect(200);

      // Intentar obtener el cliente eliminado
      await request(app)
        .get(`/api/clientes/${cliente.id_cliente}`)
        .expect(404);
    });

    test('debe retornar 404 con ID inválido', async () => {
      const response = await request(app)
        .delete('/api/clientes/abc')
        .expect(404);

      expect(response.body.success).toBe(false);
    });
  });

  // ============================================
  // TESTS DE HEADERS Y SEGURIDAD
  // ============================================

  describe('Seguridad y Headers', () => {
    
    test('debe retornar Content-Type application/json', async () => {
      const response = await request(app)
        .get('/api/clientes')
        .expect('Content-Type', /json/);

      expect(response.headers['content-type']).toContain('application/json');
    });

    test('debe tener headers de seguridad (helmet)', async () => {
      const response = await request(app)
        .get('/api/clientes');

      expect(response.headers).toHaveProperty('x-content-type-options');
    });
  });
});
