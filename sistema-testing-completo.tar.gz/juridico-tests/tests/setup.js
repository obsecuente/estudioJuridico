import { sequelize } from '../src/models/index.js';

// Configuración antes de todos los tests
beforeAll(async () => {
  try {
    await sequelize.authenticate();
    console.log('✅ Conexión a DB de pruebas establecida');
  } catch (error) {
    console.error('❌ Error conectando a DB:', error);
    throw error;
  }
});

// Limpieza después de todos los tests
afterAll(async () => {
  try {
    await sequelize.close();
    console.log('✅ Conexión a DB cerrada');
  } catch (error) {
    console.error('❌ Error cerrando conexión:', error);
  }
});

// Timeout global (30 segundos)
jest.setTimeout(30000);
